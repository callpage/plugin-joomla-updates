<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_callpage
 *
 * @copyright   Copyright (C) 2015 - 2016 Callpage Sp. z.o.o. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;
if($settings['enable']) {
    if (($settings['show_to_logged_users'] && !$settings['is_user_guest']) || $settings['is_user_guest']) {
        echo $output;
    }
}
?>