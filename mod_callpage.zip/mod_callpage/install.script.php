<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_callpage
 *
 * @copyright   Copyright (C) 2015 - 2016 Callpage Sp. z.o.o. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die;
/**
 * Script file of Callpage module
 */
class mod_CallpageInstallerScript
{
    /**
     * Method to install the extension
     * $parent is the class calling this method
     *
     * @return void
     */
    function install($parent)
    {
        echo '<p>The module has been installed</p>';
    }

    /**
     * Method to uninstall the extension
     * $parent is the class calling this method
     *
     * @return void
     */
    function uninstall($parent)
    {
        echo '<p>The module has been uninstalled</p>';
    }

    /**
     * Method to update the extension
     * $parent is the class calling this method
     *
     * @return void
     */
    function update($parent)
    {
        echo '<p>The module has been updated to version' . $parent->get('manifest')->version . '</p>';
	}

    /**
     * Method to run before an install/update/uninstall method
     * $parent is the class calling this method
     * $type is the type of change (install, update or discover_install)
     *
     * @return void
     */
    function preflight($type, $parent)
    {
        echo '';
    }

    /**
     * Method to run after an install/update/uninstall method
     * $parent is the class calling this method
     * $type is the type of change (install, update or discover_install)
     *
     * @return void
     */
    function postflight($type, $parent)
    {
        $parent->getParent()->setRedirectURL('index.php?option=com_modules');
    }
}