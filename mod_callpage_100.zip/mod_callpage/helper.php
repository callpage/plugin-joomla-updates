<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_callpage
 *
 * @copyright   Copyright (C) 2015 - 2016 Callpage Sp. z.o.o. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

class ModCallpageHelper
{
    public static function getSettings($params)
    {
        $user = JFactory::getUser();
        return [
            'enable' => $params->get('enable') === '1',
            'show_to_logged_users' => $params->get('show_to_logged_users') === '1',
            'is_user_guest' => $user->guest === 1
        ];
    }

    public static function getWidgetCode($params)
    {
        return $params->get('widget_code');
    }
}