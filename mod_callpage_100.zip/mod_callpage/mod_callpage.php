<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_callpage
 *
 * @copyright   Copyright (C) 2015 - 2016 Callpage Sp. z.o.o. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;
require_once dirname(__FILE__) . '/helper.php';

$settings = ModCallpageHelper::getSettings($params);
$output = ModCallpageHelper::getWidgetCode($params);

require JModuleHelper::getLayoutPath('mod_callpage');